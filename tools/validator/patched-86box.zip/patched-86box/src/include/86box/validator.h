#include <86box/event.h>

#define DEFAULT_QUEUE_SIZE 1024
#define DEFAULT_BUFFER_SIZE 1024 * 1024 * 1024

enum State {
    Waiting, 
    Running, 
    Finished
};

enum Register {	
    _AX,
	_CX,
	_DX,
	_BX,
	_SP,
	_BP,
	_SI,
	_DI,
	_ES,
	_CS,
	_SS,
	_DS
};

typedef struct {
	char* output;
    enum State state;
    bool in_scope;
    uint32_t start_addr, end_addr;
} validator_t;

typedef struct {
    uint8_t data[DEFAULT_BUFFER_SIZE];
    uint32_t idx;
} buffer_t;

void validator_init(const char* output, uint32_t start_addr, uint32_t end_addr);
void validator_begin(uint8_t opcode, uint8_t opcode_ext, uint16_t ip, uint16_t flags, uint16_t regs[12]);
void validator_end(uint16_t ip, uint16_t flags, uint16_t regs[12]);
void validator_shutdown(void);

void encode_event(_event_t event);
void append_to_buffer(uint8_t byte);
void push_event(void);

void validator_write(void);
void validator_discard(void);

uint32_t get_addr(uint16_t _cs, uint16_t ip);
void validator_read_byte(uint32_t addr, uint8_t data);
void validator_write_byte(uint32_t addr, uint8_t data);