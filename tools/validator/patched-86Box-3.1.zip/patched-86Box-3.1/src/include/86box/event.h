#include <stdbool.h>

#define EVENT_SIZE 158

#define EMPTY_MEM_OP { UINT32_MAX, 0 }
#define EMPTY_MEM_OPS { EMPTY_MEM_OP, EMPTY_MEM_OP, EMPTY_MEM_OP, EMPTY_MEM_OP, EMPTY_MEM_OP, EMPTY_MEM_OP, EMPTY_MEM_OP, EMPTY_MEM_OP, EMPTY_MEM_OP, EMPTY_MEM_OP };

typedef struct {
    uint16_t ip, flags;
    uint16_t regs[12];
} regs_info_t;

typedef struct {
    uint32_t addr;
    uint8_t data;
} mem_op_t;

typedef struct {
    uint8_t opcode, opcode_ext;
    regs_info_t before, after;
    mem_op_t reads[10], writes[10];
} _event_t;