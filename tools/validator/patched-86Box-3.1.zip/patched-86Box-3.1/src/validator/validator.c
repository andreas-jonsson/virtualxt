#include <stdint.h>
#include <stdio.h>

#include <86box/86box.h>
#include <86box/validator.h>

#include <zlib.h>

validator_t validator;
_event_t curr_event;

gzFile *fi;

buffer_t encoded_events = {.data = {0}, .idx = 0};

void
validator_init(const char* output, uint32_t start_addr, uint32_t end_addr)
{
    if (output[0] == '\0') 
    {
        return;
    } 
    else if (start_addr == 0) 
    {
        validator.state = Running;
    }

    validator.output = output;
    validator.start_addr = start_addr;
    validator.end_addr = end_addr;

    fi = (gzFile *)gzopen(validator.output, "wb");
    if (fi == NULL)
        pclog("Failed to open validator output!");
        return;

    return;
}

void
validator_begin(uint8_t opcode, uint8_t opcode_ext, uint16_t ip, uint16_t flags, uint16_t regs[12])
{
    if (validator.output == NULL || validator.state == Finished) 
    {
        return;
    } 
    else if (validator.state == Waiting) 
    {
        if (get_addr(regs[_CS], ip) == validator.start_addr) 
        {
            pclog("Validator started at 0x%04X.\n", validator.start_addr);
            validator.state = Running;
        } 
        else 
        {
            return;
        }
    }

    validator.in_scope = true;

    mem_op_t tmp[10] = EMPTY_MEM_OPS;
    memcpy(curr_event.reads, tmp, sizeof(mem_op_t) * 10);
    memcpy(curr_event.writes, tmp, sizeof(mem_op_t) * 10);

    curr_event.opcode = opcode;
    curr_event.opcode_ext = opcode_ext;

    curr_event.before.ip = ip;
    curr_event.before.flags = flags;

    memcpy(curr_event.before.regs, regs, sizeof(uint16_t) * 12);
    return;
}

void 
validator_end(uint16_t ip, uint16_t flags, uint16_t regs[12])
{
    if (!validator.in_scope || validator.state != Running)
    {
        return;
    }

    curr_event.after.ip = ip;
    curr_event.after.flags = flags;
    memcpy(curr_event.after.regs, regs, sizeof(uint16_t) * 12);

    validator.in_scope = false;
    push_event();

    if (get_addr(regs[_CS], ip) == validator.end_addr) 
    {
        pclog("Validator stopped at 0x%04X.\n", validator.end_addr);
        validator_shutdown();
    }
}

void
validator_shutdown(void)
{
    if (validator.state != Running)
    {
        return;
    }
    validator.state = Finished;

    if (encoded_events.idx != 0)
    {
        validator_write();
    }
    gzclose(fi);
}

void 
encode_event(_event_t event)
{
    append_to_buffer(event.opcode);
    append_to_buffer(event.opcode_ext);

    regs_info_t infos[2] = {event.before, event.after};
    for (int i = 0; i < 2; i++)
    {
        append_to_buffer(infos[i].ip >> 0x8);
        append_to_buffer(infos[i].ip & 0xff);
        append_to_buffer(infos[i].flags >> 0x8);
        append_to_buffer(infos[i].flags & 0xff);

        for (int j = 0; j < 12; j++)
        {
            append_to_buffer(infos[i].regs[j] >> 0x8);
            append_to_buffer(infos[i].regs[j] & 0xff);
        }
    }

    mem_op_t* events[2] = {event.reads, event.writes};
    for (int i = 0; i < 2; i++)
    {
        mem_op_t* ops = events[i];

        for (int j = 0; j < 10; j++)
        {
            append_to_buffer(ops[j].addr >> 0x18);
            append_to_buffer(ops[j].addr >> 0x10 & 0xff);
            append_to_buffer(ops[j].addr >> 0x8 & 0xff);
            append_to_buffer(ops[j].addr & 0xff);
            append_to_buffer(ops[j].data);
        }
    }
}

void
append_to_buffer(uint8_t byte)
{
    encoded_events.data[encoded_events.idx] = byte;
    encoded_events.idx++;
}

void
push_event(void)
{
    encode_event(curr_event);

    if (encoded_events.idx >= DEFAULT_BUFFER_SIZE)
    {
        pclog("Flushing events...");
        validator_write();
    }
}

void
validator_write(void)
{
    gzwrite(fi, encoded_events.data, encoded_events.idx);

    memset(encoded_events.data, 0, sizeof(encoded_events));
    encoded_events.idx = 0;
    return;
}

void
validator_discard(void)
{
    validator.in_scope = false;
}

uint32_t
get_addr(uint16_t cs, uint16_t ip)
{
    return cs << 16 | ip;
}

void
validator_read_byte(uint32_t addr, uint8_t data)
{
#ifdef ENABLE_VALIDATOR
    if (!validator.in_scope || validator.state != Running)
    {
        return;
    }

    for (int i = 0; i < 10; i++)
    {
        if (curr_event.reads[i].addr == UINT32_MAX)
        {
            mem_op_t op = {addr, data};
            curr_event.reads[i] = op;
            return;
        }
    }

    pclog("Max reads reached!");
#endif
}

void
validator_write_byte(uint32_t addr, uint8_t data)
{
#ifdef ENABLE_VALIDATOR
    if (!validator.in_scope || validator.state != Running)
    {
        return;
    }

    for (int i = 0; i < 10; i++)
    {
        if (curr_event.writes[i].addr == UINT32_MAX)
        {
            mem_op_t op = {addr, data};
            curr_event.writes[i] = op;
            return;
        }
    }

    pclog("Max writes reached!");
#endif
}